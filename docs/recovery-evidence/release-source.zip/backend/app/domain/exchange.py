"""Inventory-backed exchange fulfillment. All counters are changed under stock row locks."""
from __future__ import annotations
from uuid import uuid4
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import AfterSalesCase, AfterSalesItem, ExchangeFulfillment, FulfillmentIncident, InventoryReservation, InventoryStock, OrderItem
from .service import _audit


def _incident(db: Session, case: AfterSalesCase, code: str, detail: str) -> None:
    if db.scalar(select(FulfillmentIncident).where(FulfillmentIncident.case_id == case.id, FulfillmentIncident.dedupe_key == f"exchange:{code}")) is None:
        db.add(FulfillmentIncident(id=str(uuid4()), case_id=case.id, incident_type=code, detail=detail, dedupe_key=f"exchange:{code}"))


def reserve_exchange(db: Session, case: AfterSalesCase, replacement_sku: str | None = None) -> ExchangeFulfillment | None:
    """Reserve a replacement at confirmation. Stock shortage is an operational fact, never a fake shipment."""
    if case.request_type != "exchange": return None
    existing = db.scalar(select(ExchangeFulfillment).where(ExchangeFulfillment.case_id == case.id).with_for_update())
    if existing is not None and existing.status != "cancelled": return existing
    lines = list(db.scalars(select(AfterSalesItem).where(AfterSalesItem.case_id == case.id)))
    if len(lines) != 1:
        case.status = "fulfillment_exception"; _incident(db, case, "EXCHANGE_MULTI_LINE_REQUIRES_OPS", "多商品换货需运营确认替换规格。")
        _audit(db, case.id, "EXCHANGE_STOCK_EXCEPTION", "多商品换货等待运营处理。", "system", "inventory", None); return None
    item = db.scalar(select(OrderItem).where(OrderItem.id == lines[0].order_item_id))
    assert item is not None
    target_sku = replacement_sku or item.sku
    stock = db.scalar(select(InventoryStock).where(InventoryStock.sku == target_sku).with_for_update())
    if stock is None or stock.available_quantity - stock.reserved_quantity < lines[0].quantity:
        case.status = "fulfillment_exception"; _incident(db, case, "EXCHANGE_OUT_OF_STOCK", "替换商品库存不足，等待补货、退款或人工处理。")
        _audit(db, case.id, "EXCHANGE_STOCK_EXCEPTION", "替换商品库存不足。", "system", "inventory", None); return None
    reservation = db.scalar(select(InventoryReservation).where(InventoryReservation.case_id == case.id).with_for_update())
    if reservation is None:
        reservation = InventoryReservation(id=str(uuid4()), case_id=case.id, sku=target_sku, quantity=lines[0].quantity, status="reserved")
        db.add(reservation)
    reservation.sku, reservation.quantity, reservation.status = target_sku, lines[0].quantity, "reserved"
    reservation.expires_at = datetime.now(timezone.utc) + timedelta(hours=24)
    reservation.released_at, reservation.release_reason = None, None
    stock.reserved_quantity += reservation.quantity; stock.version += 1
    db.flush()  # PostgreSQL must see the parent reservation before the fulfillment FK.
    fulfillment = existing or ExchangeFulfillment(id=str(uuid4()), case_id=case.id, replacement_sku=target_sku, quantity=reservation.quantity, reservation_id=reservation.id, status="allocated")
    fulfillment.replacement_sku, fulfillment.quantity, fulfillment.status = target_sku, reservation.quantity, "allocated"
    fulfillment.failure_code = None
    db.add(fulfillment); _audit(db, case.id, "EXCHANGE_INVENTORY_RESERVED", f"已预占 {item.sku} x{reservation.quantity}。", "system", "inventory", reservation.id)
    return fulfillment


def release_exchange_reservation(db: Session, case: AfterSalesCase, reason: str) -> bool:
    reservation = db.scalar(select(InventoryReservation).where(InventoryReservation.case_id == case.id).with_for_update())
    if reservation is None or reservation.status != "reserved": return False
    stock = db.scalar(select(InventoryStock).where(InventoryStock.sku == reservation.sku).with_for_update())
    if stock is not None:
        stock.reserved_quantity = max(0, stock.reserved_quantity - reservation.quantity); stock.version += 1
    reservation.status, reservation.released_at, reservation.release_reason = "released", datetime.now(timezone.utc), reason
    fulfillment = db.scalar(select(ExchangeFulfillment).where(ExchangeFulfillment.case_id == case.id).with_for_update())
    if fulfillment is not None: fulfillment.status, fulfillment.failure_code, fulfillment.version = "cancelled", reason, fulfillment.version + 1
    _audit(db, case.id, "EXCHANGE_RESERVATION_RELEASED", reason, "system", "inventory", reservation.id)
    return True


def consume_exchange_reservation(db: Session, case: AfterSalesCase, tracking_number: str | None = None) -> ExchangeFulfillment | None:
    reservation = db.scalar(select(InventoryReservation).where(InventoryReservation.case_id == case.id).with_for_update())
    fulfillment = db.scalar(select(ExchangeFulfillment).where(ExchangeFulfillment.case_id == case.id).with_for_update())
    if reservation is None or fulfillment is None: return None
    if reservation.status == "consumed": return fulfillment
    if reservation.status != "reserved": return None
    stock = db.scalar(select(InventoryStock).where(InventoryStock.sku == reservation.sku).with_for_update())
    if stock is None or stock.available_quantity < reservation.quantity:
        release_exchange_reservation(db, case, "STOCK_INCONSISTENCY")
        case.status = "fulfillment_exception"; fulfillment.status, fulfillment.failure_code = "failed", "STOCK_INCONSISTENCY"; _incident(db, case, "STOCK_INCONSISTENCY", "预占库存无法出库。")
        return fulfillment
    stock.reserved_quantity = max(0, stock.reserved_quantity - reservation.quantity); stock.available_quantity -= reservation.quantity; stock.version += 1
    reservation.status = "consumed"; fulfillment.status, fulfillment.tracking_number, fulfillment.version = "shipped", tracking_number, fulfillment.version + 1
    _audit(db, case.id, "EXCHANGE_REPLACEMENT_SHIPPED", "替换商品已出库。", "system", "inventory", fulfillment.id)
    return fulfillment


def release_expired_reservations(db: Session, now: datetime | None = None) -> int:
    """Maintenance worker: expire unshipped inventory holds without touching consumed stock."""
    now = now or datetime.now(timezone.utc); released = 0
    rows = list(db.scalars(select(InventoryReservation).where(InventoryReservation.status == "reserved", InventoryReservation.expires_at.is_not(None), InventoryReservation.expires_at <= now).with_for_update(skip_locked=True)))
    for reservation in rows:
        case = db.get(AfterSalesCase, reservation.case_id)
        if case is None: continue
        if release_exchange_reservation(db, case, "RESERVATION_EXPIRED"):
            case.status = "fulfillment_exception"
            _incident(db, case, "EXCHANGE_RESERVATION_EXPIRED", "换货库存预占已过期，请重新选择换货或联系人工处理。")
            released += 1
    db.commit(); return released
