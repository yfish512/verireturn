export type TicketStatus = "open" | "claimed" | "waiting_customer" | "approved" | "rejected" | "closed" | "expired";

export interface Ticket {
  id: string; requester_id: string; order_id: string; request_type: "refund" | "exchange"; reason: string;
  trigger_code: string; priority: "normal" | "high"; status: TicketStatus; assigned_operator_id: string | null;
  due_at: string; version: number; policy_version_id: string; created_at: string; updated_at: string;
}

export interface ReviewEvent {
  sequence_no: number; event_type: string; payload: Record<string, unknown>; actor_id: string; actor_role: string;
  request_id: string | null; created_at: string;
}

export interface Metrics {
  tickets_total: number; tickets_by_status: Record<string, number>; backlog: number; sla_breached: number;
  review_approval_rate: number; manual_intervention_rate: number; automatic_case_share: number;
  p95_review_resolution_minutes: number | null;
}

export type KnowledgeAudience = "customer" | "operator" | "shared";
export type KnowledgeVersionStatus = "draft" | "indexing" | "ready" | "published" | "retired";

export interface KnowledgeVersion {
  id: string; document_id: string; version: number; status: KnowledgeVersionStatus; content_checksum: string;
  embedding_model: string; published_by: string | null; published_at: string | null; retired_at: string | null; created_at: string;
}

export interface KnowledgeDocument {
  id: string; stable_key: string; title: string; audience: KnowledgeAudience; category: string;
  created_by: string; created_at: string; updated_at: string; versions: KnowledgeVersion[];
}

export type FulfillmentIncidentStatus = "open" | "acknowledged" | "resolved";
export interface FulfillmentIncident {
  id: string; case_id: number; inbox_event_id: string | null; incident_type: string; detail: string;
  status: FulfillmentIncidentStatus; assigned_operator_id: string | null; version: number;
  resolution_note: string | null; created_at: string; updated_at: string;
}

export interface ObservabilityOverview { metrics: Record<string, number>; alerts_open: number; }
export interface MetricSnapshot { id: string; metric_name: string; window_start: string; window_end: string; dimensions: Record<string, unknown>; value: number; created_at: string; }
export interface OpsAlert { id: string; rule_version_id: string; metric_snapshot_id: string; severity: string; status: "open" | "acknowledged" | "resolved" | "muted"; assigned_operator_id: string | null; version: number; resolution_note: string | null; created_at: string; updated_at: string; }
export interface AlertRuleVersion { id: string; rule_key: string; version: number; metric_name: string; comparison: ">" | ">="; threshold: number; severity: "warning" | "critical"; status: "draft" | "published" | "retired"; created_by: string; created_at: string; published_at: string | null; }
export interface TraceProjection { run_id: string | null; case_ids: number[]; tool_calls: Array<Record<string, unknown>>; audit_events: Array<Record<string, unknown>>; review_tickets: Array<Record<string, unknown>>; knowledge_retrievals: Array<Record<string, unknown>>; fulfillment_events: Array<Record<string, unknown>>; outbox_events: Array<Record<string, unknown>>; incidents: Array<Record<string, unknown>>; }
export interface EvaluationRun { id: string; suite_id: string; suite_key: string; requested_by: string; model_name: string; prompt_version: string; status: "queued" | "running" | "succeeded" | "failed"; attempts: number; report_json: Record<string, unknown> | null; last_error: string | null; created_at: string; finished_at: string | null; }
export interface EvaluationResult { id: string; evaluation_run_id: string; case_id: string; status: string; latency_ms: number; evidence_json: Record<string, unknown>; created_at: string; }

export interface AgentTaskMemory {
  task_id: string;
  intent: string;
  phase: "collecting_slots" | "ready_to_execute" | "awaiting_customer_confirmation" | "awaiting_pickup_slot" | "awaiting_resolution" | "waiting_stock" | "completed" | "cancelled" | "expired";
  slots: Record<string, unknown>;
  missing_slots: string[];
  case_id: number | null;
  version: number;
}

export interface AgentMessage {
  thread_id: string;
  run_id: string;
  status: "completed" | "awaiting_confirmation" | "failed";
  response: string;
  recovery_id?: string | null;
  recovery_status?: string | null;
  confirmation_id: string | null;
  case_id: number | null;
  ticket_id: string | null;
  retrieval_id: string | null;
  citations: string[];
  memory: AgentTaskMemory | null;
}

export interface AgentThreadSnapshot {
  thread_id: string;
  messages: Array<{ id: string; role: "customer" | "agent"; content: string; payload: AgentMessage | null }>;
  task: AgentTaskMemory | null;
  next_before_sequence: number | null;
  tasks: AgentTaskMemory[];
}

export interface AgentTaskCancelResult {
  thread_id: string;
  response: string;
  task: AgentTaskMemory | null;
}

export interface AgentToolCall {
  sequence_no: number;
  graph_node: string;
  tool_name: string;
  arguments_json: Record<string, unknown>;
  result_json: Record<string, unknown> | null;
  m1_request_id: string;
  latency_ms: number;
  status: string;
  error_code: string | null;
}

export interface FulfillmentStatus {
  case_id: number;
  status: string;
  events: Array<{ id: string; event_type: string; sequence_no: number; occurred_at: string }>;
  notifications: Array<{ id: string; template: string; status: string; created_at: string }>;
}

export interface PickupSlot { start_at: string; end_at: string; timezone: string; label: string; available: number; }

export interface OrderLine { id: string; sku: string; title: string; quantity: number; refunded_quantity: number; available_after_sales_quantity: number; unit_amount: string; }

export interface CustomerRecovery { id:string; status:string; version:number; case_id:number|null; options:Array<{option:string;replacement_sku?:string}>|null; steps:Array<{sequence_no:number;kind:string;detail:Record<string,unknown>}>; next_before:number|null; }
export interface Resolution { id:string; case_id:number; option:string; replacement_sku:string|null; status:string; version:number; expires_at:string; linked_case_id:number|null; }
